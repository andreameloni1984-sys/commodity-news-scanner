"""
SOYUZ GAGARIN GATE AUDIT v1.0
Diagnostic-only: never authorizes or modifies an entry.
"""

from __future__ import annotations
from typing import Any, Dict, Iterable, List, Optional

GATES = ("REGIME", "STRUCTURE", "SETUP", "TRIGGER", "RISK", "SAFETY")


def _text(value: Any, default: str = "") -> str:
    if value is None:
        return default
    s = str(value).strip()
    return s if s else default


def _bool(value: Any) -> Optional[bool]:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return bool(value)
    s = str(value).strip().lower()
    if s in {"true", "1", "yes", "ok", "pass", "passed", "confirmed"}:
        return True
    if s in {"false", "0", "no", "fail", "failed", "blocked"}:
        return False
    return None


def _first(data: Dict[str, Any], keys: Iterable[str], default=None):
    for key in keys:
        if key in data and data[key] is not None:
            return data[key]
    return default


def _gate_value(data: Dict[str, Any], gate: str) -> Optional[bool]:
    keys = {
        "REGIME": ("regime_ok", "regime_pass", "gate_regime"),
        "STRUCTURE": ("structure_ok", "structure_pass", "gate_structure"),
        "SETUP": ("setup_ok", "setup_pass", "gate_setup"),
        "TRIGGER": ("trigger_ok", "trigger_pass", "gate_trigger"),
        "RISK": ("risk_ok", "risk_pass", "gate_risk"),
        "SAFETY": ("safety_ok", "safety_pass", "gate_safety"),
    }[gate]

    value = _bool(_first(data, keys))
    if value is not None:
        return value

    for container_key in ("gates", "gagarin_gates", "gate_status", "gate_results"):
        container = data.get(container_key)
        if isinstance(container, dict):
            value = _first(container, (gate, gate.lower(), gate.title()))
            if isinstance(value, dict):
                value = _first(value, ("ok", "pass", "passed", "confirmed"))
            value = _bool(value)
            if value is not None:
                return value
    return None


def _list_value(data: Dict[str, Any], keys: Iterable[str]) -> List[str]:
    raw = _first(data, keys, [])
    if isinstance(raw, str):
        return [x.strip() for x in raw.split(",") if x.strip()]
    if isinstance(raw, (list, tuple, set)):
        return [_text(x) for x in raw if _text(x)]
    return []


def _blocker_implies_gate(gate: str, blockers: List[str]) -> Optional[bool]:
    mapping = {
        "REGIME": {"REGIME_UNKNOWN", "REGIME_FAIL", "REGIME_BLOCKED"},
        "STRUCTURE": {"STRUCTURE_FAIL", "STRUCTURE_NOT_CONFIRMED"},
        "SETUP": {"NO_SETUP", "SETUP_CANDIDATE_NOT_CONFIRMED", "SETUP_FAIL", "SETUP_BLOCKED"},
        "TRIGGER": {"TRIGGER_NOT_CONFIRMED", "TRIGGER_FAIL", "PREDICTION_NOT_CONFIRMED"},
        "RISK": {"STOP_GT_MAX_ATR", "RR_TP1_FAIL", "RR_TP2_FAIL", "RR_MAIN_FAIL", "RISK_FAIL"},
        "SAFETY": {"SAFETY_BLOCK", "SAFETY_FAIL", "REVERSAL_CONFIRMED"},
    }
    return False if any(b in mapping[gate] for b in blockers) else None


def audit_candidate(
    commodity: str,
    candidate: Dict[str, Any],
    gagarin: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    merged = dict(candidate or {})
    if isinstance(gagarin, dict):
        merged.update({k: v for k, v in gagarin.items() if k not in merged})

    blockers = _list_value(merged, ("blockers", "gagarin_blockers", "BLOCKERS"))
    warnings = _list_value(merged, ("warnings", "gagarin_warnings"))

    gates = {}
    for gate in GATES:
        value = _gate_value(merged, gate)
        if value is None:
            value = _blocker_implies_gate(gate, blockers)
        if value is True:
            status, reason = "PASS", "Gate superato."
        elif value is False:
            status = "FAIL"
            reason = {
                "REGIME": "Regime non confermato.",
                "STRUCTURE": "Struttura non confermata.",
                "SETUP": "Setup operativo non confermato.",
                "TRIGGER": "Trigger Gagarin non confermato.",
                "RISK": "Rischio non conforme: stop/RR/ATR.",
                "SAFETY": "Safety gate bloccato.",
            }[gate]
        else:
            status, reason = "UNKNOWN", "Stato gate non esplicitamente disponibile."
        gates[gate] = {"status": status, "reason": reason}

    trigger_engine = _bool(_first(merged, ("trigger_confirmed", "trigger_engine_confirmed")))
    gagarin_trigger = _bool(_first(merged, ("gagarin_trigger_confirmed", "gagarin_trigger")))
    disagreement = trigger_engine is True and gagarin_trigger is not True
    if disagreement:
        gates["TRIGGER"]["reason"] = (
            "DISALLINEAMENTO: Trigger Engine=TRUE, Gagarin Trigger Gate!=TRUE."
        )

    failed = [g for g in GATES if gates[g]["status"] == "FAIL"]
    unknown = [g for g in GATES if gates[g]["status"] == "UNKNOWN"]

    return {
        "commodity": commodity,
        "diagnostic_only": True,
        "entry_authorized": False,
        "gates": gates,
        "failed_gates": failed,
        "unknown_gates": unknown,
        "first_blocker": failed[0] if failed else (unknown[0] if unknown else None),
        "second_blocker": failed[1] if len(failed) > 1 else None,
        "trigger_engine_confirmed": trigger_engine,
        "gagarin_trigger_confirmed": gagarin_trigger,
        "trigger_disagreement": disagreement,
        "blockers": blockers,
        "warnings": warnings,
    }


def format_audit(report: Dict[str, Any]) -> str:
    lines = [
        "GAGARIN GATE AUDIT",
        f"Commodity: {report.get('commodity', '?')}",
        "ENTRY AUTHORIZED: NO (diagnostic only)",
        "",
    ]
    for gate in GATES:
        item = report["gates"][gate]
        lines.append(f"{gate:<10} {item['status']:<7} | {item['reason']}")
    lines += [
        "",
        f"FIRST BLOCKER: {report.get('first_blocker') or 'NONE'}",
        f"SECOND BLOCKER: {report.get('second_blocker') or 'NONE'}",
        f"TRIGGER ENGINE: {report.get('trigger_engine_confirmed')}",
        f"GAGARIN TRIGGER: {report.get('gagarin_trigger_confirmed')}",
        f"TRIGGER DISAGREEMENT: {report.get('trigger_disagreement')}",
    ]
    if report.get("blockers"):
        lines.append("BLOCKERS: " + ", ".join(report["blockers"]))
    return "\n".join(lines)


def audit_results(results: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    return {
        commodity: audit_candidate(
            commodity,
            result if isinstance(result, dict) else {},
            result.get("gagarin") if isinstance(result, dict) else None,
        )
        for commodity, result in (results or {}).items()
    }
