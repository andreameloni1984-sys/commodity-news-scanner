SOYUZ GAGARIN GATE AUDIT v1.0
Diagnostic-only module.

It reports PASS/FAIL/UNKNOWN for:
REGIME, STRUCTURE, SETUP, TRIGGER, RISK, SAFETY.

It also detects:
Trigger Engine = TRUE while Gagarin Trigger Gate != TRUE.

It NEVER authorizes an entry, lowers thresholds, or bypasses Gagarin.

Suggested use after Gagarin evaluation:
from soyuz_gagarin_gate_audit import audit_candidate, format_audit
report = audit_candidate(name, result, result.get("gagarin"))
print(format_audit(report))
