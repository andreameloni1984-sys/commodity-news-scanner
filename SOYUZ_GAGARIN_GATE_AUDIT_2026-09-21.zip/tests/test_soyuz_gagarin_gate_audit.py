from soyuz_gagarin_gate_audit import audit_candidate

def test_detects_trigger_disagreement():
    r = audit_candidate("Rame", {
        "trigger_confirmed": True,
        "gagarin_trigger_confirmed": False,
        "blockers": ["NO_SETUP", "STOP_GT_MAX_ATR", "PREDICTION_NOT_CONFIRMED"],
    })
    assert r["trigger_disagreement"] is True
    assert r["gates"]["SETUP"]["status"] == "FAIL"
    assert r["gates"]["RISK"]["status"] == "FAIL"

def test_never_authorizes():
    r = audit_candidate("Oro", {
        "regime_ok": True, "structure_ok": True, "setup_ok": True,
        "trigger_ok": True, "risk_ok": True, "safety_ok": True,
    })
    assert r["diagnostic_only"] is True
    assert r["entry_authorized"] is False
