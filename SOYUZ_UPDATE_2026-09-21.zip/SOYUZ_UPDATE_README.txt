SOYUZ UPDATE — 21/09/2026

1) Sostituisci in GitHub soyuz_shadow_integration.py con il file incluso.
2) Aggiungi soyuz_social_intelligence.py alla root del repository.
3) Sostituisci .github/workflows/commodity-bot.yml con commodity-bot.yml incluso.
4) Il workflow installa youtube-transcript-api 1.2.4.
5) Telegram pubblico iniziale: BorsaFinanzaNotizie.
6) Instagram resta opzionale: per usarlo crea il secret SOYUZ_INSTAGRAM_ACCESS_TOKEN e valorizza SOYUZ_INSTAGRAM_USER_IDS nel workflow.
7) Nessun social puo autorizzare un ingresso: i dati entrano solo nel Market Intelligence/SOYUZ Shadow.
8) Non abbassare i gate Gagarin.
