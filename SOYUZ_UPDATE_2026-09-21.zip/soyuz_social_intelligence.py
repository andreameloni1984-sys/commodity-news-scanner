"""
SOYUZ SOCIAL INTELLIGENCE v1.0

Optional, read-only social intelligence layer for public sources.
- Telegram: public channel pages (t.me/s/<channel>)
- Instagram: Meta Graph API for configured professional-account IDs

This module NEVER authorizes trades and never changes Gagarin gates.
It returns bounded evidence that can be consumed by SOYUZ Market Intelligence.
"""
from __future__ import annotations

import html
import os
import re
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, Iterable, List

import requests

TIMEOUT = float(os.getenv("SOYUZ_SOCIAL_TIMEOUT_SECONDS", "8"))
MAX_ITEMS = int(os.getenv("SOYUZ_SOCIAL_MAX_ITEMS_PER_SOURCE", "20"))
LOOKBACK_HOURS = float(os.getenv("SOYUZ_SOCIAL_LOOKBACK_HOURS", "24"))
TELEGRAM_CHANNELS = [x.strip().lstrip("@") for x in os.getenv("SOYUZ_TELEGRAM_CHANNELS", "").split(",") if x.strip()]
INSTAGRAM_USER_IDS = [x.strip() for x in os.getenv("SOYUZ_INSTAGRAM_USER_IDS", "").split(",") if x.strip()]
INSTAGRAM_ACCESS_TOKEN = os.getenv("SOYUZ_INSTAGRAM_ACCESS_TOKEN", "").strip()
INSTAGRAM_GRAPH_VERSION = os.getenv("SOYUZ_INSTAGRAM_GRAPH_VERSION", "v23.0").strip()

COMMODITY_KEYWORDS = {
    "Oro": ["gold", "oro", "xau"],
    "Argento": ["silver", "argento", "xag"],
    "Rame": ["copper", "rame", "hg1"],
    "Platino": ["platinum", "platino", "xpt"],
    "Palladio": ["palladium", "palladio", "xpd"],
    "Petrolio WTI": ["wti", "crude oil", "petrolio wti"],
    "Petrolio Brent": ["brent", "petrolio brent"],
    "Benzina RBOB": ["rbob", "gasoline", "benzina"],
    "Heating Oil": ["heating oil", "gasolio"],
    "Gas Naturale": ["natural gas", "natgas", "gas naturale"],
    "Grano": ["wheat", "grano"],
    "Mais": ["corn", "mais"],
    "Soia": ["soybean", "soia", "soy"],
    "Riso": ["rice", "riso"],
    "Zucchero": ["sugar", "zucchero"],
    "Cacao": ["cocoa", "cacao"],
    "Caffè": ["coffee", "caffè", "cafe", "arabica", "robusta"],
    "Cotone": ["cotton", "cotone"],
    "Bovini vivi": ["live cattle", "cattle", "bovini"],
    "Feeder Cattle": ["feeder cattle", "feedercattle"],
    "Maiali magri": ["lean hogs", "hogs", "maiali"],
}

BULLISH = [
    "bullish", "buy", "long", "upside", "rally", "breakout", "support",
    "rialzo", "rialzista", "comprare", "acquisto", "long", "salita", "rottura",
]
BEARISH = [
    "bearish", "sell", "short", "downside", "drop", "dump", "breakdown", "resistance",
    "ribasso", "ribassista", "vendere", "short", "discesa", "crollo", "rottura al ribasso",
]

@dataclass
class SocialItem:
    source: str
    channel: str
    text: str
    published_at: str = ""
    url: str = ""

@dataclass
class SocialSignal:
    commodity: str
    score: float = 0.0
    confidence: float = 0.0
    bullish_mentions: int = 0
    bearish_mentions: int = 0
    mentions: int = 0
    sources: int = 0
    items: List[Dict[str, Any]] | None = None


def _norm(text: Any) -> str:
    return re.sub(r"\s+", " ", html.unescape(str(text or ""))).strip()


def _count_hits(text: str, words: Iterable[str]) -> int:
    low = text.lower()
    return sum(len(re.findall(r"(?<!\w)" + re.escape(w.lower()) + r"(?!\w)", low)) for w in words)


def _parse_iso(value: str) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def _recent(dt: datetime | None) -> bool:
    if dt is None:
        return True
    now = datetime.now(timezone.utc)
    return dt >= now - timedelta(hours=LOOKBACK_HOURS)


def fetch_telegram_public() -> List[SocialItem]:
    out: List[SocialItem] = []
    headers = {"User-Agent": "SOYUZ-GAGARIN/1.0"}
    for channel in TELEGRAM_CHANNELS:
        try:
            url = f"https://t.me/s/{channel}"
            r = requests.get(url, headers=headers, timeout=TIMEOUT)
            r.raise_for_status()
            text = r.text
            blocks = re.findall(r'<div class="tgme_widget_message_wrap".*?</div>\s*</div>\s*</div>', text, re.S)
            if not blocks:
                blocks = re.findall(r'<div class="tgme_widget_message[^>]*>.*?</div>\s*</div>', text, re.S)
            for block in blocks[-MAX_ITEMS:]:
                plain = _norm(re.sub(r"<[^>]+>", " ", block))
                if not plain:
                    continue
                mdate = re.search(r'datetime="([^"]+)"', block)
                published = mdate.group(1) if mdate else ""
                mlink = re.search(r'href="(https://t\.me/[^\"]+)"', block)
                link = mlink.group(1) if mlink else url
                if _recent(_parse_iso(published)):
                    out.append(SocialItem("telegram", f"@{channel}", plain[:2500], published, link))
        except Exception as exc:
            print(f"⚠️ SOYUZ SOCIAL Telegram {channel}: {type(exc).__name__}: {exc}")
    return out


def fetch_instagram_graph() -> List[SocialItem]:
    out: List[SocialItem] = []
    if not INSTAGRAM_ACCESS_TOKEN or not INSTAGRAM_USER_IDS:
        return out
    headers = {"User-Agent": "SOYUZ-GAGARIN/1.0"}
    for user_id in INSTAGRAM_USER_IDS:
        try:
            url = f"https://graph.facebook.com/{INSTAGRAM_GRAPH_VERSION}/{user_id}/media"
            params = {
                "fields": "id,caption,timestamp,permalink,username",
                "limit": str(MAX_ITEMS),
                "access_token": INSTAGRAM_ACCESS_TOKEN,
            }
            r = requests.get(url, params=params, headers=headers, timeout=TIMEOUT)
            r.raise_for_status()
            payload = r.json()
            for row in payload.get("data", []):
                published = str(row.get("timestamp") or "")
                if not _recent(_parse_iso(published)):
                    continue
                caption = _norm(row.get("caption"))
                if not caption:
                    continue
                username = row.get("username") or user_id
                out.append(SocialItem("instagram", f"@{username}", caption[:2500], published, row.get("permalink") or ""))
        except Exception as exc:
            print(f"⚠️ SOYUZ SOCIAL Instagram {user_id}: {type(exc).__name__}: {exc}")
    return out


def classify(items: List[SocialItem]) -> Dict[str, Dict[str, Any]]:
    result: Dict[str, SocialSignal] = {k: SocialSignal(k, items=[]) for k in COMMODITY_KEYWORDS}
    for item in items:
        text = item.text
        bull = _count_hits(text, BULLISH)
        bear = _count_hits(text, BEARISH)
        if bull == 0 and bear == 0:
            continue
        for commodity, keywords in COMMODITY_KEYWORDS.items():
            if not any(re.search(r"(?<!\w)" + re.escape(k.lower()) + r"(?!\w)", text.lower()) for k in keywords):
                continue
            sig = result[commodity]
            sig.mentions += 1
            sig.sources += 1
            sig.bullish_mentions += bull
            sig.bearish_mentions += bear
            sig.score += (bull - bear) * 12.0
            sig.items.append(asdict(item))
    final: Dict[str, Dict[str, Any]] = {}
    for commodity, sig in result.items():
        sig.score = max(-100.0, min(100.0, sig.score))
        if sig.mentions:
            sig.confidence = min(100.0, 35.0 + sig.mentions * 8.0 + min(30.0, abs(sig.bullish_mentions - sig.bearish_mentions) * 3.0))
        final[commodity] = asdict(sig)
    return final


def collect_social_intelligence() -> Dict[str, Any]:
    enabled = os.getenv("SOYUZ_SOCIAL_INTELLIGENCE_ENABLED", "1") == "1"
    if not enabled:
        return {"enabled": False, "items": 0, "signals": {}}
    items = fetch_telegram_public() + fetch_instagram_graph()
    signals = classify(items)
    active = {k: v for k, v in signals.items() if v["mentions"] > 0}
    print(f"📡 SOYUZ SOCIAL INTELLIGENCE | items={len(items)} | commodities_with_signal={len(active)}")
    for k, v in sorted(active.items(), key=lambda kv: abs(kv[1]["score"]), reverse=True)[:8]:
        print(f"   {k}: score={v['score']:.1f} conf={v['confidence']:.1f} mentions={v['mentions']} sources={v['sources']}")
    return {"enabled": True, "items": len(items), "signals": signals}
